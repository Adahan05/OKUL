//
//  ViewController.swift
//  OKUL DESTEK
//
//  Created by Adahan on 19.11.2017.
//  Copyright © 2017 Okul Destek. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }


    @IBAction func addButtonClicked(_ sender: Any) {
        performSegue(withIdentifier: "toOdevVC", sender: nil)
        
    }
    


}

